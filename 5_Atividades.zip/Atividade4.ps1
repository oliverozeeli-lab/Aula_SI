﻿Clear-Host

$opcao = "S"

while ($opcao -eq "S") {

    Clear-Host

    Write-Host "===== CALCULOS MATEMATICOS =====" -ForegroundColor Cyan

    $acertos = 0
    $continuar = "S"

    while ($continuar -eq "S") {

        try {

            $numero1 = Get-Random -Minimum 2 -Maximum 101
            $numero2 = Get-Random -Minimum 2 -Maximum 101

            $operadores = "+","-","*"
            $operador = $operadores | Get-Random

            switch ($operador) {

                "+" {
                    $resultado = $numero1 + $numero2
                }

                "-" {
                    $resultado = $numero1 - $numero2
                }

                "*" {
                    $resultado = $numero1 * $numero2
                }
            }

            $resposta = Read-Host "$numero1 $operador $numero2 = "

            if ($resposta -eq $resultado) {

                $acertos = $acertos + 1

                Write-Host "Acertou!" -ForegroundColor Green
                Write-Host "Total de acertos: $acertos" -ForegroundColor Yellow
    

            } else {

                Write-Host "Errou!" -ForegroundColor Red
                Write-Host "Resposta correta: $resultado" -ForegroundColor Yellow
                Write-Host "Total de acertos: $acertos" -ForegroundColor Cyan

                $continuar = "N"
            }

        } catch {

            Write-Host "Erro no calculo!" -ForegroundColor Red

        }

    }

    $opcao = Read-Host "Deseja recomeçar? (S ou N)"

}