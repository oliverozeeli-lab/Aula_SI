﻿Clear-Host

Write-Host "===== CONTADOR CUSTOMIZADO =====" -ForegroundColor Cyan

[int]$inicio = Read-Host "Digite o numero inicial"
[int]$incremento = Read-Host "Digite o valor do incremento"
[int]$fim = Read-Host "Digite o numero final"
$ordem = Read-Host "Digite a ordem (C para Crescente ou D para Decrescente)"

Write-Host "Resultado:" -ForegroundColor Yellow

switch ($ordem) {

    "C" {
        try {
            while ($inicio -le $fim) {
                Write-Host $inicio -ForegroundColor Green
                $inicio = $inicio + $incremento
            }
        } catch {
            Write-Host "Erro na contagem crescente!" -ForegroundColor Red
        }

        Start-Sleep -Seconds 3
    }

    "D" {
        try {
            while ($inicio -ge $fim) {
                Write-Host $inicio -ForegroundColor Magenta
                $inicio = $inicio - $incremento
            }
        } catch {
            Write-Host "Erro na contagem decrescente!" -ForegroundColor Red
        }
    }
}