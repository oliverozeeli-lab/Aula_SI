﻿Clear-Host

$resposta = "S"

while ($resposta -eq "S") {

    Clear-Host

    try {

        $pc = Get-Random -Minimum 1 -Maximum 4

        switch ($pc) {
            1 { $escolhaPC = "PEDRA" }
            2 { $escolhaPC = "PAPEL" }
            3 { $escolhaPC = "TESOURA" }
        }

        Write-Host "===== JO-KEN-PO =====" -ForegroundColor Cyan
        Write-Host "1 - PEDRA"
        Write-Host "2 - PAPEL"
        Write-Host "3 - TESOURA"

        $op = Read-Host "Escolha uma opcao"

        switch ($op) {
            1 { $escolha = "PEDRA" }
            2 { $escolha = "PAPEL" }
            3 { $escolha = "TESOURA" }
        }

        Write-Host ""
        Write-Host "Voce escolheu: $escolha"
        Write-Host "Computador escolheu: $escolhaPC"
        Write-Host ""

        if ($op -eq $pc) {
            Write-Host "EMPATOU!" -ForegroundColor Yellow
        }

        if ($op -eq 1) {

            if ($pc -eq 3) {
                Write-Host "VOCE VENCEU!" -ForegroundColor Green
            }

            if ($pc -eq 2) {
                Write-Host "VOCE PERDEU!" -ForegroundColor Red
            }
        }

        if ($op -eq 2) {

            if ($pc -eq 1) {
                Write-Host "VOCE VENCEU!" -ForegroundColor Green
            }

            if ($pc -eq 3) {
                Write-Host "VOCE PERDEU!" -ForegroundColor Red
            }
        }

        if ($op -eq 3) {

            if ($pc -eq 2) {
                Write-Host "VOCE VENCEU!" -ForegroundColor Green
            }

            if ($pc -eq 1) {
                Write-Host "VOCE PERDEU!" -ForegroundColor Red
            }
        }

        Write-Host ""

        $resposta = Read-Host "Deseja jogar novamente? (S ou N)"

    } catch {

        Write-Host "Erro no jogo!" -ForegroundColor Red

    }

}