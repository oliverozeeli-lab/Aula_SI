﻿Clear-Host

Write-Host "===== SERIE DE FIBONACCI =====" -ForegroundColor Cyan

$quantidade = Read-Host "Digite a quantidade de numeros da serie"

$num1 = 0
$num2 = 1
$contador = 1

Write-Host "Serie de Fibonacci:" -ForegroundColor Yellow

while ($contador -le $quantidade) {

    Write-Host $num1 -ForegroundColor Green

    $proximo = $num1 + $num2
    $num1 = $num2
    $num2 = $proximo

    $contador = $contador + 1
}