﻿Clear-Host

Write-Host "===== TABUADA ALEATORIA =====" -ForegroundColor Cyan

try {

    $numero = Get-Random -Minimum 1 -Maximum 20

    Write-Host "Numero sorteado: $numero" -ForegroundColor Yellow
    Write-Host "Tabuada:" -ForegroundColor Green

    $contador = 1

    while ($contador -le 10) {

        $resultado = $numero * $contador

        Write-Host "$numero x $contador = $resultado"

        $contador = $contador + 1
    }

} catch {

    Write-Host "Erro ao gerar a tabuada!" -ForegroundColor Red

}