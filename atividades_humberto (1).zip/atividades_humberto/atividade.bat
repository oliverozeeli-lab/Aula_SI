chcp 65001
@echo off
color 0a
:inicio
cls
echo.
set /p nome=Digite o Nome do Jogador :
goto:jogo

:jogo
cls
set /a numero=(%random% %% 50) + 1
set /a tentativas=5
echo ╔══════════════════════════════════════╗
echo ║   Adivinhar Numero entre 01 e 50     ║
echo ║══════════════════════════════════════║
echo         Seja Bem-Vindo! %nome%             
echo ╚══════════════════════════════════════╝

:rodada
echo         Tentativas restantes: %tentativas% 
echo ----------------------------------------
echo [P] Pontuacao
echo [E] Encerrar
echo ======================================
set /p palpite=Digite seu palpite:
if /i %palpite% == p goto:pontuacao
if /i %palpite% == e goto:inicio

if %palpite% LSS 1 goto:invalido
if %palpite% GTR 50 goto:invalido

if %palpite% EQU %numero% goto:ganhou
if %palpite% GTR %numero% (
    echo Digite um numero MENOR!
) else (
    echo Digite um numero MAIOR!
)
set /a tentativas-=1
if %tentativas% EQU 0 goto:perdeu
goto:rodada

:invalido
echo Digite um numero entre 1 e 50!
goto:rodada

:ganhou
echo.
echo Parabens!!!
echo O numero era: %numero%
echo -----------------------------------------
echo %date%      %time%         %tentativas%         %numero%         %nome% >> vencedores.txt
set /p resp=Deseja jogar novamente? [S/N] :
if /i %resp% == s (goto:jogo) else (goto:inicio)

:perdeu
echo.
echo Que pena!!!
echo Vc Perdeu!
echo O numero era: %numero%
echo -------------------------------------------
set /p resp=Deseja jogar novamente? [S/N] :
if /i %resp% == s (goto:jogo) else (goto:inicio)

:pontuacao
cls
echo.
echo ╔════════════════════════════════════════════════════════════════╗
echo ║  █████████    LISTAGEM DE JOGADORES - VENCEDORES    █████████  ║
echo ║════════════════════════════════════════════════════════════════║
echo ║DATA             HORA          TENTATIVAS    NUMERO      NOME   ║
echo ║════════════════════════════════════════════════════════════════║
type ║vencedores.txt                                                  ║
echo ╚════════════════════════════════════════════════════════════════╝
echo.
pause
goto:jogo