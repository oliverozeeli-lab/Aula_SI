dim numeros
num = cint(inputbox("Digite um numero inteiro:", "Antecessor e sucessor"))

antecessor = num - 1
sucessor = num + 1

msgbox "numero: " & num & vbnewline & _
       "antecessor: " & antecessor & vbnweline & _
       "sucessor: " & sucessor 
