dim n1,n2,n3, maior, menor

n1= cint(inputbox("Digite o primeiro numero: ", "comparacao"))
n2 = cint(inputbox("Digite o segundo numero: ", "comparacao"))
n3 = cint(inputbox("Digite o terceiro numero: ", "comparacao"))

maior = n1
menor= n1

if n2 > maior then maior = n2
if n3 > maior then maior = n3

if n2 < maior then maior = n2
if n3 < maior then maior = n3

msgbox "Maior numero: " & maior & vbnewline &_
       "Menor numero: " & menor 

