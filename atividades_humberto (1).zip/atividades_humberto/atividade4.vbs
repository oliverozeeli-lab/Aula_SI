dim salarioMin, qtdSalarios, salarioBruto,inss, salarioLiquido

salarioMin = 1621
 qtdSalarios = CDbl(inputbox("Digite a quantidade de salarios: ", "Folha de pagamento"))

 salarioBruto = qtdSalarios * salarioMin
 if salarioBruto <= 1621 then
    inss = salarioBruto * 0.075
 elseif  salarioBruto <= 2902.84 then 
    inss = salarioBruto * 0.09
 elseif salarioBruto <= 4354.27 then 
    inss = salarioBruto * 0.12
 else
    inss = salarioBruto * 0.14
 end if

 salarioLiquido = salarioBruto - inss

 msgbox "Salario Bruto: R$ " & salarioBruto & vbnewline &_
        "INSS: R$ " & inss & vbnewline &_
        "Salario Liquido: R$ " & salarioLiquido






