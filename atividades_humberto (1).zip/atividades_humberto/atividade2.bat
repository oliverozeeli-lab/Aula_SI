chcp 65001
@echo off
color 0a
:inicio
cls
echo.
set /a empate= 0
set /a vitoria= 0
set /a perdeu= 0
set /p nome=Digite o Nome do Jogador :
goto:jogo

:jogo
cls
set /a pc=(%random% %% 5) + 1
if %pc%==1 set escolhaPC=PEDRA
if %pc%==2 set escolhaPC=PAPEL
if %pc%==3 set escolhaPC=TESOURA
if %pc%==4 set escolhaPC=LAGARTO
if %pc%==5 set escolhaPC=SPOCK
echo ----------------------------------------
echo Digite seu nome: %nome%
echo ----------------------------------------
echo.
echo                (o o)
echo --------ooO-----(_)----Ooo--------------
echo     Bem-Vindo ao JO-KEN-PO 
echo ----------------------------------------
echo [1] PEDRA
echo [2] PAPEL
echo [3] TESOURA
echo [4] LAGARTO
echo [5] SPOCK
echo [E] ENCERRAR JOGO
echo [R] REGRAS
echo ===========================================
set /p op=Escolha uma opcao:
if %op%==1 set escolha=PEDRA
if %op%==2 set escolha=PAPEL
if %op%==3 set escolha=TESOURA
if %op%==4 set escolha=LAGARTO
if %op% ==5 set escolha=SPOCK

if %op%==%pc% (
    echo %nome% escolheu: %op%!
    echo Computador escolheu: %pc%!
    echo.
    echo OPS...DEU EMPATE!!!
    set /a empate=%empate%+1
    echo.
    goto:placar
)

if  %op% == 1 (
    if %pc% == 3 (goto:ganhou)
    if %pc% == 4 (goto:ganhou)
    if %pc% == 2 (goto:perdeu)
    if %pc% == 5 (goto:perdeu)
)
if %op% == 2 (
    if %pc% == 1 (goto:ganhou)
    if %pc% == 5 (goto:ganhou)
    if %pc% == 3 (goto:perdeu)
    if %pc% == 4 (goto:perdeu)
)
if %op% == 3 (
    if %pc% == 2 (goto:ganhou)
    if %pc% == 4 (goto:ganhou)
    if %pc% == 1 (goto:perdeu)
    if %pc% == 5 (goto:perdeu)
)
if %op% == 4 (
    if %pc% == 2 (goto:ganhou)
    if %pc% == 5 (goto:ganhou)
    if %pc% == 1 (goto:perdeu)
    if %pc% == 3 (goto:perdeu)
)
if %op% == 5 (
    if %pc% == 1 (goto:ganhou)
    if %pc% == 3 (goto:ganhou)
    if %pc% == 4 (goto:perdeu)
    if %pc% == 2 (goto:perdeu) 
)
if /i %op% == e (exit)
if /i %op% == r (goto:regras) else (
echo.
echo -------------------------------
echo        Opcao invalida!!!
echo -------------------------------
echo.
pause
goto:jogo
)

:regras
cls
echo Pedra:
echo    Empata com Pedra; Ganha de Tesoura e Lagarto; Perde de Papel e Spock;
echo.
echo Papel:
echo    Empata com Papel; Ganha de Pedra e Spock; Perde de Tesoura e Lagarto;
echo.
echo Tesoura:
echo    Empata com Tesoura; Ganha de Lagarto e Papel; Perde de Pedra e Spock;
echo.
echo Lagarto:
echo    Empata com Lagarto; Ganha de Papel e Spock; Perde de Pedra e Tesoura;
echo.
echo Spock:
echo    Empata com Spock; Ganha de Pedra e Tesoura; Perde de Lagarto e Papel;
echo.
echo Pressione qualquer tecla para continuar...
pause
goto:jogo

:ganhou
    echo %nome% escolheu: %escolha%!
    echo Computador escolheu: %escolhaPC%!
    echo.
    echo PARABENS... VOCE VENCEU!!!
    set /a vitoria=%vitoria%+1
    echo.
    goto:placar

:perdeu
    echo %nome% escolheu: %escolha%!
    echo Computador escolheu: %escolhaPC%!
    echo.
    echo QUE PENA... VOCE PERDEU!!!
    set /a perdeu=%perdeu%+1
    echo.
    goto:placar

:placar
echo.
echo ==== PLACAR DO JOGO =====
echo Vitorias: %vitoria%
echo Derrotas: %perdeu%
echo Empates: %empate%
echo ==========================
echo.
set /p resp=Deseja jogar novamente? [S/N] :
if /i %resp% == s (goto:jogo) else (goto:inicio)

