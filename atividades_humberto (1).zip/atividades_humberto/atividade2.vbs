dim lado,area,perimetro
lado= CDbl(inputBox("Digite o valor do lado do quadrado:", "Quadrado"))

area = lado * ladoperimetro= 4 * lado
msgbox "lado: " & lado & vbnewline &_
        "area: " & area & vbnewlinw &_
        "perimetro: " & perimetro

